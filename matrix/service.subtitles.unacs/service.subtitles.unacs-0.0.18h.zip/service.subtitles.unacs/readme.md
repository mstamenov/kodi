# Kodi subtitles service for [unacs.bg](https://subsunacs.net/)
Upgraded for python 3 - default interpreter for Kodi 19 matrix  
The older version of subtitle service supports only python2

# Installation 
 - Go to parent folder
 - Get the source code of the repo via git or download
 - Archive folder service.subtitles.unacs as zip
 - Open Kodi -> Addons -> Install from zip
 - Select created zip archive  

